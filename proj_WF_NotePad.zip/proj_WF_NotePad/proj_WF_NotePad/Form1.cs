﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Diagnostics;

namespace proj_WF_NotePad
{
    public partial class nodepadForm : Form
    {
        int Ln = 1;
        int Col = 1;
        string pt = "";
        bool save_flag = false;
        bool TextWasChanged = false;
        int countss = 0;
        SaveFileDialog saveFileDialog = new SaveFileDialog();
        OpenFileDialog openFileDialog = new OpenFileDialog();
        public string contents = string.Empty;
        public nodepadForm()
        {
            InitializeComponent();
            this.AllowDrop = true;
            richTextBox.AllowDrop = true;
            this.richTextBox.DragEnter += nodepadForm_DragEnter;
            this.richTextBox.DragDrop += nodepadForm_DragDrop;
        }
        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
             
        }
        private void undoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTextBox.Undo();
        }
        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if(richTextBox.SelectedText.Length >0)
            {
                int sLength = richTextBox.SelectionLength;
                richTextBox.Text = richTextBox.Text.Remove(richTextBox.SelectionStart, sLength);
                richTextBox.SelectionStart = richTextBox.SelectionStart + richTextBox.Text.Length;
            }
            change_Pest();
        }
        private void pasteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTextBox.Paste();
        }
        private void copyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTextBox.Copy();
            change_Pest();
        }
        private void cutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTextBox.Cut();
        }
        private void selectAllToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTextBox.SelectAll();
        }
        private void change_Pest()
        {
            cutToolStripMenuItem.Enabled = false;
            copyToolStripMenuItem.Enabled = false;
            deleteToolStripMenuItem.Enabled = false;
            undoToolStripMenuItem.Enabled = true; 
            pasteToolStripMenuItem.Enabled = true;
            selectAllToolStripMenuItem.Enabled = true;

            undoToolStripMenuItem1.Enabled = true;
            pasteToolStripMenuItem1.Enabled = true;
            selectAllToolStripMenuItem1.Enabled = true;
            cutToolStripMenuItem1.Enabled = false;
            copyToolStripMenuItem1.Enabled = false;
            deleteToolStripMenuItem1.Enabled = false;
        }
        private void openToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            openFileDialog.Filter = "Text Files (*.txt)|*.txt|All Files (*.*)|*.*";
            if (openFileDialog.ShowDialog(this) == DialogResult.OK)
            {
                richTextBox.Clear();
                string path = openFileDialog.FileName;
                pt = path;
                int pos = path.LastIndexOf("\\");
                string ss = path.Substring(pos + 1);
                this.Text = ss + " - Notepad";

                StreamReader sr = new StreamReader(path);
                richTextBox.Text += sr.ReadToEnd();
                sr.Close();
            }
            TextWasChanged = false;
            richTextBox.Modified = false;
        }
        private void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (this.Text == "Untitled - Notepad")
            {
                string path = "";
                saveFileDialog.DefaultExt = ".txt";
                saveFileDialog.FileName = "*.txt";
                saveFileDialog.Filter = "Text Files (*.txt)|*.txt|All Files (*.*)|*.*";
                if (saveFileDialog.ShowDialog() == DialogResult.OK)
                {
                    path = saveFileDialog.FileName;
                    pt = path;
                    if (!File.Exists(path))
                    {
                        path = saveFileDialog.FileName;
                        pt = path;
                        int pos = path.LastIndexOf("\\");
                        string ss = path.Substring(pos + 1);
                        this.Text = ss + " - Notepad";
                        using (StreamWriter sWriter = File.CreateText(path))
                        {
                            for (int i = 0; i < richTextBox.Lines.Length; i++)
                            {
                                sWriter.WriteLine(richTextBox.Lines[i]);
                                countss = countss + richTextBox.Lines[i].Length + 1;
                                save_flag = true;
                            }
                        }
                        countss = countss - 1;
                        TextWasChanged = false;
                    }
                }
            }
            else
            {
                richTextBox.SaveFile(openFileDialog.FileName, RichTextBoxStreamType.PlainText);
                richTextBox.Focus();
                richTextBox.Modified = false;
            }
        }
        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (richTextBox.Modified == true)
            {
                DialogResult dr = MessageBox.Show("Do you want to save the file before exiting", "unsaved file", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (dr == DialogResult.Yes)
                {
                    String filter = "Text Files|*.txt|All Files|*.*";
                    saveFileDialog.Filter = filter;
                    if (saveFileDialog.ShowDialog(this) == DialogResult.OK)
                    {
                        richTextBox.SaveFile(saveFileDialog.FileName, RichTextBoxStreamType.PlainText);
                    }
                    else
                        return;
                }
                else
                {
                    richTextBox.Modified = false;
                    Application.Exit();
                }
            }
            else
            {
                richTextBox.Clear();
                Application.Exit();
            }
        }
        private void timeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var insertText = DateTime.Now.ToString();
            var selectionIndex = richTextBox.SelectionStart;
            richTextBox.Text = richTextBox.Text.Insert(selectionIndex, insertText);
            richTextBox.SelectionStart = selectionIndex + insertText.Length;
        }
        private void statusbarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (statusbarToolStripMenuItem.Checked == false)
            {
                statusbarToolStripMenuItem.Checked = true;
                statusStrip1.Visible = true;
            }
            else
            {
                statusbarToolStripMenuItem.Checked = false;
                statusStrip1.Visible = false;
            }
        }
        private void fontToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FontDialog fontDialog = new FontDialog();
            fontDialog.Font = richTextBox.Font;
            fontDialog.ShowColor = true;
            fontDialog.ShowEffects = true;
            if (fontDialog.ShowDialog(this) == DialogResult.OK)
            {
                richTextBox.ForeColor = fontDialog.Color;
                richTextBox.Font = fontDialog.Font;
            }
        }
        private void wordWrapToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.AutoSize = false;
            if (wordWrapToolStripMenuItem.Checked == false)
            {
                wordWrapToolStripMenuItem.Checked = true;
                richTextBox.WordWrap = true;
            }
            else
            {
                wordWrapToolStripMenuItem.Checked = false;
                richTextBox.WordWrap = false;
            }
        }
        private void saveAsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            saveFileDialog.DefaultExt = ".txt";
            saveFileDialog.FileName = "*.txt";
            saveFileDialog.Filter = "Text Files (*.txt)|*.txt|All Files (*.*)|*.*";
            if (saveFileDialog.ShowDialog(this) == DialogResult.OK)
            {
                string path = saveFileDialog.FileName;
                path = saveFileDialog.FileName;
                pt = path;
                int pos = path.LastIndexOf("\\");
                string ss = path.Substring(pos + 1);
                this.Text = ss + " - Notepad";
                if (!File.Exists(path)) 
                {
                    using (StreamWriter sWriter = File.CreateText(path))
                    {
                        for (int i = 0; i < richTextBox.Lines.Length; i++)
                        {
                            sWriter.WriteLine(richTextBox.Lines[i]);
                        }
                    }
                }
                else if (File.Exists(path))  
                {
                    using (StreamWriter sWriter = File.CreateText(path))
                    {
                        for (int i = 0; i < richTextBox.Lines.Length; i++)
                        {
                            sWriter.WriteLine(richTextBox.Lines[i]);
                        }
                    }
                }
            }
        }
        private void newToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (richTextBox.Modified == true && richTextBox.Text.Length > 0)
            {
                DialogResult dr = MessageBox.Show("Do You want to save the changes made to " + this.Text, "Save", MessageBoxButtons.YesNoCancel);
                if (dr == DialogResult.Yes)
                {
                    saveFileDialog.Title = "Save";
                    if (SaveFile() == 0)
                        return;
                    else
                    {
                        richTextBox.Text = "";
                        this.Text = "Untitled - Notepad";
                    }
                    contents = "";
                }
                else if (dr == DialogResult.No)
                {
                    richTextBox.Text = "";
                    this.Text = "Untitled - Notepad";
                    contents = "";
                }
                else
                    richTextBox.Focus();
            }
            else
            {
                this.Text = "Untitled - Notepad";
                richTextBox.Text = "";
                contents = "";
            }
        }
        private int SaveFile()
        {
            saveFileDialog.Filter = "Text Documents|*.txt";
            saveFileDialog.DefaultExt = "txt";
            if (saveFileDialog.ShowDialog() == DialogResult.Cancel)
            {
                richTextBox.Focus();
                return 0;
            }
            else
            {
                contents = richTextBox.Text;
                if (this.Text == "Untitled - Notepad")
                    richTextBox.SaveFile(saveFileDialog.FileName, RichTextBoxStreamType.PlainText);
                else
                {
                    saveFileDialog.FileName = this.Text;
                    richTextBox.SaveFile(saveFileDialog.FileName, RichTextBoxStreamType.PlainText);
                }
                this.Text = saveFileDialog.FileName;
                return 1;
            }
        }
        private void richTextBox_TextChanged(object sender, EventArgs e)
        {
            TextWasChanged = true;
            richTextBox.Modified = true;
        }
        private void nodepadForm_Load(object sender, EventArgs e)
        {
            this.Text = "Untitled - Notepad";
            this.richTextBox.Clear();
            toolStripStatusLabel.Text = "Ln " + Ln + " , " + "   Col " + Col;
            this.richTextBox.AllowDrop = true;
        }
        private void nodepadForm_FormClosing(object sender, FormClosingEventArgs e)
        {
           
        }
        private void nodepadForm_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.FileDrop))
                e.Effect = DragDropEffects.Copy;
            else
                e.Effect = DragDropEffects.None;
        }
        private void nodepadForm_DragDrop(object sender, DragEventArgs e)
        {
            object filename = e.Data.GetData("FileDrop");
            if (filename != null)
            {
                var list = filename as string[];
                if (list != null && !string.IsNullOrWhiteSpace(list[0]))
                {
                    this.richTextBox.Clear();
                    this.richTextBox.LoadFile(list[0], RichTextBoxStreamType.PlainText);
                }
            }
        }
        private void richTextBox_SelectionChanged(object sender, EventArgs e)
        {
            int currentIndex = richTextBox.SelectionStart;
            Ln = richTextBox.GetLineFromCharIndex(currentIndex);
            int firstLineCharIndex = richTextBox.GetFirstCharIndexFromLine(Ln);
            Col = currentIndex - firstLineCharIndex;
            toolStripStatusLabel.Text = "Ln " + (Ln + 1) +" , "+ "   Col " + (Col + 1);

            if (richTextBox.SelectedText.Length > 0)
            {
                selectAllToolStripMenuItem1.Enabled = false;

                undoToolStripMenuItem1.Enabled = true;
                cutToolStripMenuItem1.Enabled = true;
                copyToolStripMenuItem1.Enabled = true;
                pasteToolStripMenuItem1.Enabled = true;
                deleteToolStripMenuItem1.Enabled = true;
            }
            else
            {
                undoToolStripMenuItem1.Enabled = true;
                pasteToolStripMenuItem1.Enabled = true;
                selectAllToolStripMenuItem1.Enabled = true;

                cutToolStripMenuItem1.Enabled = false;
                copyToolStripMenuItem1.Enabled = false;
                deleteToolStripMenuItem1.Enabled = false;
            }
        }
        private void nodepadForm_KeyDown(object sender, KeyEventArgs e)
        {
           if (e.Alt == true)
           {
                fileToolStripMenuItem.Text = "&File";
                editToolStripMenuItem.Text = "&Edit";
                formatToolStripMenuItem.Text = "F&ormat";
                viewToolStripMenuItem.Text = "&View";
                newToolStripMenuItem.Text = "&New";
                openToolStripMenuItem.Text = "&Open";
                saveToolStripMenuItem.Text = "&Save";
                saveAsToolStripMenuItem.Text = "Save &As";
                exitToolStripMenuItem.Text = "E&xit";

                undoToolStripMenuItem.Text = "&Undo";
                cutToolStripMenuItem.Text = "Cu&t";
                copyToolStripMenuItem.Text = "&Copy";
                pasteToolStripMenuItem.Text = "&Paste";
                deleteToolStripMenuItem.Text = "De&lete";
                selectAllToolStripMenuItem.Text = "Select &All";
                timeToolStripMenuItem.Text = "Time/&Date";

                wordWrapToolStripMenuItem.Text = "&Word Wrap";
                fontToolStripMenuItem.Text = "&Font...";

                statusbarToolStripMenuItem.Text = "&Status Bar";
           }
        }
        private void editToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if(richTextBox.SelectedText.Length > 0)
            {
                undoToolStripMenuItem.Enabled = true;
                cutToolStripMenuItem.Enabled = true;
                copyToolStripMenuItem.Enabled = true;
                selectAllToolStripMenuItem.Enabled = true;
                pasteToolStripMenuItem.Enabled = true;
                deleteToolStripMenuItem.Enabled = true;
            }
            else
            {
                undoToolStripMenuItem.Enabled = true;
                pasteToolStripMenuItem.Enabled = true;
                selectAllToolStripMenuItem.Enabled = true;
                timeToolStripMenuItem.Enabled = true;

                cutToolStripMenuItem.Enabled = false;
                copyToolStripMenuItem.Enabled = false;
                deleteToolStripMenuItem.Enabled = false;
            }
        }
        private void contextMenuStrip1_Click(object sender, EventArgs e)
        {
           
        }
        private void undoToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            richTextBox.Undo();
        }
        private void cutToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            richTextBox.Cut();
        }
        private void copyToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            richTextBox.Copy();
        }
        private void pasteToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            richTextBox.Paste();
        }
        private void deleteToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            if (richTextBox.SelectedText.Length > 0)
            {
                int sLength = richTextBox.SelectionLength;
                richTextBox.Text = richTextBox.Text.Remove(richTextBox.SelectionStart, sLength);
                richTextBox.SelectionStart = richTextBox.SelectionStart + richTextBox.Text.Length;
            }
            change_Pest();
        }
        private void selectAllToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            richTextBox.SelectAll();
        }
        private void nodepadForm_MouseUp(object sender, MouseEventArgs e)
        {
            
        }
        private void nodepadForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            if (richTextBox.Modified == true)
            {
                if (this.Text == "Untitled - Notepad")
                {
                    DialogResult dr = MessageBox.Show("Do you want to save the file before exiting", "unsaved file", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                    if (dr == DialogResult.Yes)
                    {
                        string path = "";
                        saveFileDialog.DefaultExt = ".txt";
                        saveFileDialog.FileName = "*.txt";
                        saveFileDialog.Filter = "Text Files (*.txt)|*.txt|All Files (*.*)|*.*";
                        if (saveFileDialog.ShowDialog() == DialogResult.OK)
                        {
                            path = saveFileDialog.FileName;
                            pt = path;
                            if (!File.Exists(path))
                            {
                                path = saveFileDialog.FileName;
                                pt = path;
                                int pos = path.LastIndexOf("\\");
                                string ss = path.Substring(pos + 1);
                                this.Text = ss + " - Notepad";
                                using (StreamWriter sWriter = File.CreateText(path))
                                {
                                    for (int i = 0; i < richTextBox.Lines.Length; i++)
                                    {
                                        sWriter.WriteLine(richTextBox.Lines[i]);
                                        countss = countss + richTextBox.Lines[i].Length + 1;
                                        save_flag = true;
                                    }
                                }
                                countss = countss - 1;
                                TextWasChanged = false;
                            }
                        }
                    }
                    else
                        Application.Exit();
                }
                else if(TextWasChanged == true)
                {
                    DialogResult dr = MessageBox.Show("Do you want to save the file before exiting", "unsaved file", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                    if(dr == DialogResult.Yes)
                    {
                        richTextBox.SaveFile(openFileDialog.FileName, RichTextBoxStreamType.PlainText);
                        richTextBox.Modified = false;
                    }
                }
            }
            else
                Application.Exit();
        }
    }
}
